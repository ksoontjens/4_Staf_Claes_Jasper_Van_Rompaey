package hellotvxlet;

public interface SubjectInterface {
    public abstract void register(ObserverInterface ob);
    public abstract void unregister(ObserverInterface ob);
    
}
