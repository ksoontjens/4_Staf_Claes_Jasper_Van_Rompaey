// 1: GameComponent gc = ComponentFactory.getInstance("Hanne");
// 2: gc.init(x, y, bitmap, scale);

public class HanneComponent implements GameComponent extends HGraphicButton {
	@Override
	public void init(x, y, bitmap, scale){

	}

	@Override
	public void paint(Graphics h){

	}
}