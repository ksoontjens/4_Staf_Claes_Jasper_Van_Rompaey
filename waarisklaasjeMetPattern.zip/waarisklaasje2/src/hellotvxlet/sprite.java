/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package hellotvxlet;

import java.util.Random;
import org.havi.ui.HIcon;
import java.awt.Color;
import java.util.Observer;
import java.util.Timer;
import javax.tv.xlet.Xlet;
import javax.tv.xlet.XletContext;
import javax.tv.xlet.XletStateChangeException;
import org.havi.ui.HScene;
import org.havi.ui.HSceneFactory;
import org.havi.ui.HVisible;

/**
 *
 * @author student
 */
public class sprite extends HIcon  {
Random gen = new Random();
int x = gen.nextInt();
int y = gen.nextInt();


}
