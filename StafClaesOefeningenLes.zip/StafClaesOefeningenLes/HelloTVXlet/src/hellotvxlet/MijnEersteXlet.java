package hellotvxlet;

import javax.tv.xlet.*;
import org.havi.ui.*;

   public class MijnEersteXlet implements Xlet{
       private XletContext actueleXletContext;
       
        public void destroyXlet(boolean unconditional) throws XletStateChangeException {
           if (unconditional)
           {
           System.out.println("De Xlet moet be�indigd worden.");
           }
           else{
           System.out.println("De mogelijkheid bestaat" + " door het werpen van de exeptie " + "de Xlet in het leven te houden");
           throw new XletStateChangeException("Laat me leven!");
           }
        }

        public void initXlet(XletContext context) throws XletStateChangeException {
            this.actueleXletContext = context;

            
        }

        public void pauseXlet() {
            
        }

        public void startXlet() throws XletStateChangeException 
        {

        }
   
   }
  


