package hellotvxlet;

import java.awt.event.KeyEvent;
import javax.tv.xlet.Xlet;
import javax.tv.xlet.XletContext;
import javax.tv.xlet.XletStateChangeException;
import org.bluray.ui.event.HRcEvent;
import org.dvb.event.EventManager;
import org.dvb.event.UserEvent;
import org.dvb.event.UserEventListener;
import org.dvb.event.UserEventRepository;
import org.havi.ui.HScene;
import org.havi.ui.HSceneFactory;


public class HelloTVXlet implements Xlet, UserEventListener
{
    HScene scene;
    int schipx = 350;
    MijnComponent mc;

    public void destroyXlet(boolean unconditional) throws XletStateChangeException {

    }

    public void initXlet(XletContext ctx) throws XletStateChangeException {
    scene = HSceneFactory.getInstance().getDefaultHScene();
        try {
            mc = new MijnComponent(0, 0, 720, 576);
        } catch (InterruptedException ex) {
            ex.printStackTrace();
        }

    scene.add(mc);
    
    scene.validate();
    scene.setVisible(true);
    
    EventManager ev = EventManager.getInstance();
    UserEventRepository userEvents = new UserEventRepository("naam");
    userEvents.addAllArrowKeys();
    ev.addUserEventListener(this, userEvents);
    }
    
    public void userEventReceived(UserEvent e)
    {
        System.out.println(e.toString());
        if(e.getType() == KeyEvent.KEY_PRESSED)
        {
            switch (e.getCode())
            {
                case HRcEvent.VK_LEFT:
                schipx--; mc.moveschip(schipx, 450);
                break;
                case HRcEvent.VK_RIGHT:
                schipx++; mc.moveschip(schipx, 450);
                break;
            }
        }
    }

    public void pauseXlet() {
    
    }

    public void startXlet() throws XletStateChangeException {
    
    }
    
}