package hellotvxlet;

import java.awt.event.ActionEvent;
import javax.tv.xlet.*;
import org.havi.ui.*;
import org.havi.ui.event.*;
import java.awt.*;
import java.awt.event.*;
import org.dvb.ui.*;
import org.havi.ui.event.HActionListener;


public class HelloTVXlet implements Xlet, HActionListener {

    private XletContext actueleXletContext;
    private HScene scene;
    private boolean debug = true;
    
    private HTextButton knop1, knop2, knop3, knop4;
    public void initXlet(XletContext context) {
      
     if(debug) System.out.println("Xlet initialiseren");
     this.actueleXletContext = context;
     
     // Template aanmaken
     HSceneTemplate sceneTemplate = new HSceneTemplate();
     
     //Grootte en positie aangeven
     sceneTemplate.setPreference (HSceneTemplate.SCENE_SCREEN_DIMENSION, new HScreenDimension(1.0f, 1.0f), HSceneTemplate.REQUIRED);
     sceneTemplate.setPreference (HSceneTemplate.SCENE_SCREEN_LOCATION, new HScreenPoint(0.0f, 0.0f), HSceneTemplate.REQUIRED);
     
     //Een instantie van de Scene aanvragen aan de factory
     scene = HSceneFactory.getInstance().getBestScene(sceneTemplate);
     
        HStaticText hst = new HStaticText("Favoriete Console?", 100, 100, 500, 50);
        hst.setBackground(new DVBColor(255,255,255,179));
        hst.setBackgroundMode(HVisible.BACKGROUND_FILL);
        
        scene.add(hst);
     
        knop1 = new HTextButton("XBox One");
        knop1.setLocation(100, 200);
        knop1.setSize(200, 100);
        knop1.setBackground(new DVBColor(0, 0, 0, 179));
        knop1.setBackgroundMode(HVisible.BACKGROUND_FILL);
        
        scene.add(knop1);
        
        knop2 = new HTextButton("PlayStation 4");
        knop2.setLocation(400, 200);
        knop2.setSize(200, 100);
        knop2.setBackground(new DVBColor(0, 0, 0, 179));
        knop2.setBackgroundMode(HVisible.BACKGROUND_FILL);
        
        scene.add(knop2);
        
        knop3 = new HTextButton("WiiU");
        knop3.setLocation(100, 300);
        knop3.setSize(200, 100);
        knop3.setBackground(new DVBColor(0, 0, 0, 179));
        knop3.setBackgroundMode(HVisible.BACKGROUND_FILL);
        
        scene.add(knop3);
        
        knop4 = new HTextButton("PC");
        knop4.setLocation(400, 300);
        knop4.setSize(200, 100);
        knop4.setBackground(new DVBColor(0, 0, 0, 179));
        knop4.setBackgroundMode(HVisible.BACKGROUND_FILL);
        
        scene.add(knop4);
        
        knop1.setFocusTraversal(knop3, knop3, knop2, knop2);
        knop2.setFocusTraversal(knop4, knop4, knop1, knop1);
        knop3.setFocusTraversal(knop1, knop1, knop4, knop4);
        knop4.setFocusTraversal(knop2, knop2, knop3, knop3);
        
        knop1.requestFocus();
        
        knop1.setActionCommand("Halo Fanboy");
        knop2.setActionCommand("Uncharted Bitch");
        knop3.setActionCommand("Da's geen ECHTE console");
        knop4.setActionCommand("PC MASTER RACE!");
        
        knop1.addHActionListener(this);
        knop2.addHActionListener(this);
        knop3.addHActionListener(this);
        knop4.addHActionListener(this);

    }

    public void startXlet() throws XletStateChangeException {
    
     // Communicatie (In- en Uitvoer met de gebruiker)
     if(debug) System.out.println("Xlet starten");
     
     //scene zichtbaar maken
     scene.validate();
     scene.setVisible(true);
    }

    public void pauseXlet() {
     
     //vrijgeven van niet-nodige resources
    }

    public void destroyXlet(boolean unconditional) throws XletStateChangeException {
     
     if(unconditional) {
         // System.out.println geeft debug weer voor emulatoren.
         System.out.println("De Xlet moet be�indigd worden");
     }
     else {
         System.out.println("De mogelijkheid bestaat " + "door het werpen van een exceptie " + "de Xlet in leven te houden. ");
         throw new XletStateChangeException("Laat me leven");
     }
    }

    public void actionPerformed(ActionEvent e) {
        System.out.println(e.getActionCommand());
        HStaticText antwoord = new HStaticText(e.getActionCommand(), 100, 450, 500, 50);
        antwoord.setBackground(Color.LIGHT_GRAY);
        antwoord.setBackgroundMode(HVisible.BACKGROUND_FILL);
        scene.add(antwoord);
        scene.popToFront(antwoord);
        scene.repaint();
    }
}