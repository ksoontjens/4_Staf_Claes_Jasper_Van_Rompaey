package hellotvxlet;

import javax.tv.xlet.Xlet;
import javax.tv.xlet.XletContext;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Container;
import java.awt.Font;
import java.awt.Graphics;

import javax.tv.xlet.XletStateChangeException;
import org.dvb.event.EventManager;
import org.dvb.event.UserEvent;
import org.dvb.event.UserEventListener;
import org.dvb.event.UserEventRepository;
import org.havi.ui.HScene;
import org.havi.ui.HSceneFactory;

/**
 * Just a simple xlet that draws a String in the center of the screen.
 */
public class HelloTVXlet implements Xlet, UserEventListener{
HScene scene;

    public void destroyXlet(boolean unconditional) throws XletStateChangeException {
     
    }

    public void initXlet(XletContext ctx) throws XletStateChangeException {
       scene = HSceneFactory.getInstance().getDefaultHScene();
       MijnComponent mc=new MijnComponent(0,0,720,576);

       
       scene.add(mc);
       scene.validate();
       scene.setVisible(true);
       UserEventRepository userEvents = new UserEventRepository("naam");
       userEvents.addAllArrowKeys();
       EventManager ev = EventManager.getInstance();
       ev.addUserEventListener(this, userEvents);
    }

    public void pauseXlet() {
    
    }

    public void startXlet() throws XletStateChangeException {
       
    }

    public void userEventReceived(UserEvent e) {
       System.out.println(e.toString());
    }
}
