package hellotvxlet;

import javax.tv.xlet.*;
import org.havi.ui.*;

public class MijnEersteXlet implements Xlet {

  private XletContext actueleXletContext;

    public void initXlet(XletContext context) {
      
     this.actueleXletContext = context;
    }

    public void startXlet() throws XletStateChangeException {
    
     // Communicatie (In- en Uitvoer met de gebruiker)
    }

    public void pauseXlet() {
     
     //vrijgeven van niet-nodige resources
    }

    public void destroyXlet(boolean unconditional) throws XletStateChangeException {
     
     if(unconditional) {
         // System.out.println geeft debug weer voor emulatoren.
         System.out.println("De Xlet moet be�indigd worden");
     }
     else {
         System.out.println("De mogelijkheid bestaat " + "door het werpen van een exceptie " + "de Xlet in leven te houden. ");
         throw new XletStateChangeException("Laat me leven");
     }
    }
}

