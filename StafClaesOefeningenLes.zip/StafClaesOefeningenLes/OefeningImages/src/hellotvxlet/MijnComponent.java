/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package hellotvxlet;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.MediaTracker;
import org.dvb.ui.DVBColor;
import org.havi.ui.HComponent;

/**
 *
 * @author student
 */
public class MijnComponent extends HComponent{
Image banana;
    public MijnComponent(int x, int y, int w, int h) throws InterruptedException
    {
    this.setBounds(x,y,w,h);
    banana=this.getToolkit().getImage("banana.jpg");
    //schip.jpg in c://programfiles/technotrend/tt-mhp-browser/fileilo/dsmcc/0.0.3
    MediaTracker mt = new MediaTracker(this);
    mt.addImage(banana, 0);
    try{
    mt.waitForAll();
    }
    catch (InterruptedException ex) {
    ex.printStackTrace();
    }
    }
    
    public void paint(Graphics g)
    {
    g.drawImage(banana, 0,0, null);
    }
    
    
    
}
