package hellotvxlet;

import javax.tv.xlet.Xlet;
import javax.tv.xlet.XletContext;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Container;
import java.awt.Font;
import java.awt.Graphics;

import java.util.Random;
import javax.tv.xlet.XletStateChangeException;
import org.dvb.ui.DVBColor;
import org.havi.ui.HScene;
import org.havi.ui.HSceneFactory;
import org.havi.ui.HStaticText;
import org.havi.ui.HTextButton;
import org.havi.ui.HVisible;
import org.havi.ui.event.HActionListener;
import java.awt.event.ActionEvent;
import org.havi.ui.event.*;

/**
 * Just a simple xlet that draws a String in the center of the screen.
 */
public class HelloTVXlet implements Xlet, HActionListener {
HScene scene;
MijnComponent mc;
MijnComponent mc1;
MijnComponent mc2;
MijnComponent mc3;

private HTextButton knop1;

       Random gen = new Random();
       int x; //= gen.nextInt(500);
       int y; //= gen.nextInt(500);
       int z = gen.nextInt(3);

    public void destroyXlet(boolean unconditional) throws XletStateChangeException {
     
    }

    public void initXlet(XletContext ctx) throws XletStateChangeException {
       scene = HSceneFactory.getInstance().getDefaultHScene();
       
       MijnComponent mc2=null;
MijnComponent vorig=null, dubbelvorig=null;
int minx=0;
       for (int i = 0; i < 35; i++) {
     
        x = gen.nextInt(30)+i*20;
   
        minx=x;
        y = gen.nextInt(500);
        int t=gen.nextInt(13);
        String file;
        if (t==0) file="Klaasje";
        else
        {
         file="PER"+t;   
        }
        file=file+".png";
          mc2=new MijnComponent(x,y,file,50);
          mc2.setBordersEnabled(false);
          scene.add(mc2);
          
          if (vorig!=null) 
          {
              vorig.setFocusTraversal (null, null, dubbelvorig, mc2);
          //    System.out.println("setFocus"+mc2+":"+dubbelvorig);
          }         
          dubbelvorig=vorig;
          vorig=mc2;

       }
    mc2.setFocusTraversal (null, null, dubbelvorig, null);
   
       System.out.println(z);

       
       HStaticText hst = new HStaticText("Waar is Klaasje?", 100,10,500,50);
       hst.setBackground(new DVBColor(255,255,255,179));
       hst.setBackgroundMode(HVisible.BACKGROUND_FILL);
       scene.add(hst);
       scene.popToFront(hst);
       
       
       
       scene.validate();
       scene.setVisible(true);
       dubbelvorig.requestFocus();
    //   mc.requestFocus();
       
       knop1 = new HTextButton("Nog een keer!");
       knop1.setLocation(500, 450);
       knop1.setSize(200, 100);
       knop1.setBackground(new DVBColor(0, 0, 0, 179));
       knop1.setBackgroundMode(HVisible.BACKGROUND_FILL);
        
       scene.add(knop1);
       scene.popToFront(knop1);
       knop1.requestFocus();
       knop1.addHActionListener(this);
       //knop1.setActionCommand();
       
       switch(z){
        case 0: MijnComponent mcBG = new MijnComponent(720,576,"BG1.png",0);
        scene.add(mcBG);
        mcBG.setBounds(0,0,720,576);
        break;
        case 1: MijnComponent mcBG2 = new MijnComponent(720,576,"BG2.png",0);
        scene.add(mcBG2);
        mcBG2.setBounds(0,0,720,576);
        break;
        case 2: MijnComponent mcBG3 = new MijnComponent(720,576,"BG3.png",0);
        scene.add(mcBG3);
        mcBG3.setBounds(0,0,720,576);
        break;}
       
       
       /*Klaasje.setActionCommand("Jij hebt wel een oog voor het vinden van Klaasjes.");
       Klaasje.addActionListener(this); */
       
    

System.out.println(x);
System.out.println(y);
       
    }

    public void pauseXlet() {
    
    }

    public void startXlet() throws XletStateChangeException {
       
    }

    public void actionPerformed(ActionEvent arg0) {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    
}
