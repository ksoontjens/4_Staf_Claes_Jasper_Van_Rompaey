package hellotvxlet;

import java.awt.Color;
import java.awt.event.ActionEvent;
import javax.tv.xlet.*;
import org.havi.ui.*;
import org.havi.ui.event.HActionListener;

   public class HelloTVXlet implements Xlet, HActionListener {
       private XletContext actueleXletContext;
       HScene scene;
        public void destroyXlet(boolean unconditional) throws XletStateChangeException {
           if (unconditional)
           {
           System.out.println("De Xlet moet be�indigd worden.");
           }
           else{
           System.out.println("De mogelijkheid bestaat" + " door het werpen van de exeptie " + "de Xlet in het leven te houden");
           throw new XletStateChangeException("Laat me leven!");
           }
        }

        public void initXlet(XletContext context) throws XletStateChangeException {
            this.actueleXletContext = context;
            scene = HSceneFactory.getInstance().getDefaultHScene();
            
        }

        public void pauseXlet() {
            
        }

        public void startXlet() throws XletStateChangeException 
        {
            HStaticText hst = new HStaticText("Choose a side.", 0,350,750,50);
            hst.setBackground(Color.BLACK);
            hst.setBackgroundMode(HVisible.BACKGROUND_FILL);
            HTextButton button1 = new HTextButton("Sith", 150,400,200,60);
            HTextButton button2 = new HTextButton("Jedi", 400,400,200,60);
            HTextButton button3 = new HTextButton("Undecided", 150,500,200,60);
            HTextButton button4 = new HTextButton("Star Trek bitch", 400,500,200,60);
            
            button1.setBackgroundMode(HVisible.BACKGROUND_FILL);
            button2.setBackgroundMode(HVisible.BACKGROUND_FILL);
            button3.setBackgroundMode(HVisible.BACKGROUND_FILL);
            button4.setBackgroundMode(HVisible.BACKGROUND_FILL);
            button1.setBackground(Color.LIGHT_GRAY);
            button2.setBackground(Color.LIGHT_GRAY);
            button3.setBackground(Color.LIGHT_GRAY);
            button4.setBackground(Color.LIGHT_GRAY);
            button1.setFocusTraversal(button3, button3, button4, button2);
            button2.setFocusTraversal(button4, button4, button1, button3);
            button3.setFocusTraversal(button1,button1, button2, button4);
            button4.setFocusTraversal(button2, button2, button3, button1);
            button1.setActionCommand("You chose wisely");
            button2.setActionCommand("YOU REBEL SCUM!!!");
            button3.setActionCommand("The choice should be easy...");
            button4.setActionCommand("WHAT?! YOU TRAITOR! People like you should burn.");
            button1.addHActionListener(this);
            button2.addHActionListener(this);
            button3.addHActionListener(this);
            button4.addHActionListener(this);
            scene.add(hst);
            scene.add(button1);
            scene.add(button2);
            scene.add(button3);
            scene.add(button4);
            scene.validate();
            scene.setVisible(true);
            button1.requestFocus();
        }

    public void actionPerformed(ActionEvent arg0) {
        System.out.println (arg0.getActionCommand());
        HStaticText antwoord = new HStaticText(arg0.getActionCommand(), 0,300,750,50);
        antwoord.setBackground(Color.LIGHT_GRAY);
        antwoord.setBackgroundMode(HVisible.BACKGROUND_FILL);
        scene.add(antwoord);
        scene.repaint();
        scene.popToFront(antwoord);
    }
   
   }
  


